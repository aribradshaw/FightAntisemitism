import { OneMailError, isEmail, parseUrl } from './util.js';

export const KINDS = Object.freeze(['transactional', 'marketing', 'bulk']);

/**
 * Throw unless kind is one of KINDS.
 * @param {unknown} kind
 * @returns {'transactional'|'marketing'|'bulk'}
 */
export function assertKind(kind) {
  if (!KINDS.includes(/** @type {any} */ (kind))) {
    throw new OneMailError(`kind must be one of ${KINDS.join(', ')} (got ${JSON.stringify(kind)})`);
  }
  return /** @type {any} */ (kind);
}

/** Normalize "a@b.c" or "mailto:a@b.c?subject=x" to a mailto: URL, or null. */
export function toMailto(value) {
  if (value === undefined || value === null || value === '') return null;
  const raw = String(value);
  const withScheme = /^mailto:/i.test(raw) ? raw : `mailto:${raw}`;
  const address = decodeURIComponent(withScheme.slice(7).split('?')[0]);
  if (!isEmail(address) || /[\s<>"]/.test(withScheme)) {
    throw new OneMailError(`unsubscribeMailto must be an email address or mailto: URL (got ${JSON.stringify(value)})`);
  }
  return withScheme;
}

/**
 * Mail headers for a message of this kind.
 *
 * - transactional: no unsubscribe headers (receipts, codes, password resets).
 * - marketing / bulk: List-Unsubscribe with the https URL (and mailto if given)
 *   plus List-Unsubscribe-Post: List-Unsubscribe=One-Click (RFC 8058), which
 *   Gmail and Yahoo require of bulk senders. Throws without an https URL.
 *
 * The unsubscribe URL must accept a POST with body `List-Unsubscribe=One-Click`
 * and unsubscribe without further interaction.
 *
 * @param {{ kind: 'transactional'|'marketing'|'bulk', unsubscribeUrl?: string, unsubscribeMailto?: string, brand?: import('./index.js').BrandInput }} options
 * @returns {Record<string, string>}
 */
export function headers({ kind, unsubscribeUrl, unsubscribeMailto, brand } = /** @type {any} */ ({})) {
  assertKind(kind);
  if (kind === 'transactional') return {};
  const url = unsubscribeUrl ?? brand?.unsubscribe?.url;
  const mailto = unsubscribeMailto ?? brand?.unsubscribe?.mailto;
  if (url === undefined || url === null || url === '') {
    throw new OneMailError(`${kind} email needs an unsubscribeUrl (https) for one-click List-Unsubscribe`);
  }
  if (!parseUrl(url, ['https:'])) {
    throw new OneMailError(`unsubscribeUrl must be an absolute https:// URL (got ${JSON.stringify(url)})`);
  }
  const targets = [`<${url}>`];
  const mail = toMailto(mailto);
  if (mail) targets.push(`<${mail}>`);
  return {
    'List-Unsubscribe': targets.join(', '),
    'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click',
  };
}
