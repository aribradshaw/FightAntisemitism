// OneMail: branded, compliant email HTML + plain text. Zero dependencies.
export { render } from './render.js';
export { headers, KINDS } from './headers.js';
export { defineBrand, validateBrand, formatFrom, DEFAULT_COLORS, DEFAULT_DARK_COLORS } from './brand.js';
export { escapeHtml, OneMailError } from './util.js';
