export type Kind = 'transactional' | 'marketing' | 'bulk';
export type Hex = `#${string}`;
export type Align = 'left' | 'center' | 'right';

export interface ColorsInput {
  /** Button and accent color. Required. */
  primary: Hex;
  /** Link color. Defaults to primary. */
  link?: Hex;
  text?: Hex;
  muted?: Hex;
  /** Page background behind the card. */
  background?: Hex;
  /** Card background. */
  surface?: Hex;
  border?: Hex;
  buttonText?: Hex;
  /** Overrides used by clients that support prefers-color-scheme: dark. */
  dark?: Partial<Record<'primary' | 'link' | 'text' | 'muted' | 'background' | 'surface' | 'border' | 'buttonText', Hex>>;
}

export interface BrandInput {
  name: string;
  /** https URL of a transparent PNG with built-in padding (no white box). Serve at 2x logoWidth. */
  logoUrl?: string;
  /** Optional alternate logo swapped in under dark mode where supported. */
  logoDarkUrl?: string;
  /** Display width in px (16-300). Required with logoUrl. */
  logoWidth?: number;
  logoHeight?: number;
  fontFamily?: string;
  colors: ColorsInput;
  from: { name: string; email: string };
  replyTo?: string;
  footer: {
    legalName: string;
    /** Physical mailing address lines (required for commercial email). */
    address: string[];
    supportEmail?: string;
    website?: string;
    /** Extra line shown in every footer. */
    note?: string;
  };
  /** Defaults for marketing/bulk mail; per-message values override. */
  unsubscribe?: { url?: string; mailto?: string; label?: string };
}

export interface Brand extends Readonly<BrandInput> {
  readonly fontFamily: string;
  readonly colors: Readonly<Required<Omit<ColorsInput, 'dark'>>> & { readonly dark: Readonly<Required<NonNullable<ColorsInput['dark']>>> };
}

/** Plain text, or parts. Strings are never parsed for markup. */
export type Inline = string | Array<string | { text: string; href?: string; bold?: boolean; italic?: boolean }>;

export type Block =
  | { type: 'heading'; text: string; level?: 1 | 2 | 3; align?: Align }
  | { type: 'paragraph'; text: Inline; align?: Align }
  | { type: 'list'; items: Inline[]; ordered?: boolean }
  | { type: 'button'; text: string; href: string; align?: Align }
  | { type: 'code'; code: string; label?: string }
  | { type: 'keyValue' | 'table'; rows: Array<{ label: string; value: string | number; bold?: boolean }>; title?: string }
  | { type: 'divider' }
  | { type: 'image'; src: string; alt: string; width: number; height?: number; href?: string; caption?: string; align?: Align }
  | { type: 'small' | 'footnote'; text: Inline; align?: Align }
  /** Unescaped. You own the safety of `html`. */
  | { type: 'raw'; html: string; text: string };

export interface RenderOptions {
  brand: BrandInput | Brand;
  subject: string;
  preheader?: string;
  blocks: Block[];
  /** Default 'transactional'. marketing/bulk need an unsubscribe URL. */
  kind?: Kind;
  /** Per-recipient https one-click unsubscribe URL (overrides brand.unsubscribe.url). */
  unsubscribeUrl?: string;
  unsubscribeMailto?: string;
  /** Footer line such as "You get this because you joined the Acme newsletter." */
  reason?: string;
  lang?: string;
}

export interface RenderResult {
  subject: string;
  html: string;
  text: string;
  /** Same as headers({ kind, ... }): empty for transactional. */
  headers: Record<string, string>;
}

export function render(options: RenderOptions): RenderResult;
export function headers(options: { kind: Kind; unsubscribeUrl?: string; unsubscribeMailto?: string; brand?: BrandInput | Brand }): Record<string, string>;
export function defineBrand(input: BrandInput | Brand): Brand;
export function validateBrand(input: BrandInput | Brand): Brand;
export function formatFrom(brand: BrandInput | Brand): string;
export function escapeHtml(value: unknown): string;
export const KINDS: readonly Kind[];
export const DEFAULT_COLORS: Readonly<Record<string, Hex>>;
export const DEFAULT_DARK_COLORS: Readonly<Record<string, Hex>>;
export class OneMailError extends Error {
  problems: string[];
}
