import { defineBrand } from './brand.js';
import { assertKind, headers as buildHeaders } from './headers.js';
import { OneMailError, escapeHtml as h, isPlainObject, safeHref, parseUrl, assertSingleLine } from './util.js';

const WIDTH = 600;
const PAD = 32;
const CONTENT = WIDTH - PAD * 2;
const MONO = "ui-monospace, SFMono-Regular, Menlo, Consolas, 'Liberation Mono', monospace";
// Zero-width filler after the preheader so clients don't pull body text into the inbox preview.
const PREHEADER_SPACER = '&#847;&zwnj;&nbsp;'.repeat(90);

/**
 * Render an email.
 *
 * @param {import('./index.js').RenderOptions} options
 * @returns {import('./index.js').RenderResult}
 */
export function render(options) {
  if (!isPlainObject(options)) throw new OneMailError('render() needs an options object');
  const brand = defineBrand(options.brand);
  const kind = assertKind(options.kind ?? 'transactional');
  const subject = assertSingleLine(options.subject, 'subject');
  if (!subject.trim()) throw new OneMailError('subject is required');
  const preheader = options.preheader ?? '';
  if (typeof preheader !== 'string') throw new OneMailError('preheader must be a string');
  if (!Array.isArray(options.blocks) || options.blocks.length === 0) throw new OneMailError('blocks must be a non-empty array');

  const mailHeaders = buildHeaders({ kind, unsubscribeUrl: options.unsubscribeUrl, unsubscribeMailto: options.unsubscribeMailto, brand });
  const unsubscribeUrl = kind === 'transactional' ? null : (options.unsubscribeUrl ?? brand.unsubscribe?.url);
  const ctx = { brand, c: brand.colors, font: brand.fontFamily };

  const htmlBlocks = [];
  const textBlocks = [];
  options.blocks.forEach((block, index) => {
    const where = `blocks[${index}]`;
    if (!isPlainObject(block)) throw new OneMailError(`${where} must be an object with a type`);
    const renderer = BLOCKS[block.type];
    if (!renderer) throw new OneMailError(`${where}: unknown block type ${JSON.stringify(block.type)} (use ${Object.keys(BLOCKS).join(', ')})`);
    const out = renderer(block, ctx, where);
    htmlBlocks.push(out.html);
    if (out.text) textBlocks.push(out.text);
  });

  const footer = renderFooter(ctx, { kind, unsubscribeUrl, reason: options.reason });
  const html = shell(ctx, { subject, preheader, body: htmlBlocks.join('\n'), footer: footer.html, lang: options.lang || 'en' });
  const text = [...textBlocks, '--', footer.text].join('\n\n').replace(/\n{3,}/g, '\n\n') + '\n';

  return { subject, html, text, headers: mailHeaders };
}

// ---- Inline text ------------------------------------------------------------

/**
 * Inline content is a string (plain text) or an array of parts:
 * strings and { text, href?, bold?, italic? } objects. Strings are never
 * parsed for markup, so user data can't inject links or tags.
 */
function inline(content, ctx, where, { color } = {}) {
  const parts = typeof content === 'string' ? [content] : content;
  if (!Array.isArray(parts) || parts.length === 0) throw new OneMailError(`${where}: text must be a string or an array of parts`);
  const html = [];
  const text = [];
  parts.forEach((part, i) => {
    if (typeof part === 'string') {
      html.push(lineBreaks(h(part)));
      text.push(part);
      return;
    }
    if (!isPlainObject(part) || typeof part.text !== 'string') throw new OneMailError(`${where}.text[${i}] must be a string or { text, href?, bold? }`);
    let piece = lineBreaks(h(part.text));
    if (part.bold) piece = `<strong>${piece}</strong>`;
    if (part.italic) piece = `<em>${piece}</em>`;
    if (part.href !== undefined) {
      const href = safeHref(part.href, `${where}.text[${i}]`);
      piece = `<a href="${h(href)}" class="om-link" style="color:${color || ctx.c.link};text-decoration:underline">${piece}</a>`;
      text.push(linkText(part.text, href));
    } else {
      text.push(part.text);
    }
    html.push(piece);
  });
  return { html: html.join(''), text: text.join('') };
}

const lineBreaks = (escaped) => escaped.replace(/\r?\n/g, '<br>');

/** "text (url)", or just the url when the text already is the url. */
function linkText(label, href) {
  const bare = href.replace(/^mailto:/, '').replace(/^tel:/, '');
  if (!label || label === href || label === bare) return bare;
  return `${label} (${bare})`;
}

const requireString = (value, where) => {
  if (typeof value !== 'string' || !value.trim()) throw new OneMailError(`${where} is required`);
  return value;
};

const align = (value, where) => {
  if (value === undefined) return 'left';
  if (!['left', 'center', 'right'].includes(value)) throw new OneMailError(`${where}.align must be left, center or right`);
  return value;
};

const row = (inner, style = '') => `<tr><td style="${style}">${inner}</td></tr>`;

// ---- Blocks -----------------------------------------------------------------

const BLOCKS = {
  heading(block, ctx, where) {
    const level = block.level ?? 1;
    if (![1, 2, 3].includes(level)) throw new OneMailError(`${where}.level must be 1, 2 or 3`);
    const size = { 1: 24, 2: 19, 3: 16 }[level];
    const { html, text } = inline(requireString(block.text, `${where}.text`), ctx, where);
    const a = align(block.align, where);
    return {
      html: row(`<h${level} class="om-text" style="margin:0;font-family:${ctx.font};font-size:${size}px;line-height:1.3;font-weight:700;color:${ctx.c.text};text-align:${a}">${html}</h${level}>`, `padding:0 0 16px 0`),
      text: level === 1 ? `${text}\n${'='.repeat(Math.min(text.length, 60))}` : text,
    };
  },

  paragraph(block, ctx, where) {
    const { html, text } = inline(block.text, ctx, where);
    const a = align(block.align, where);
    return {
      html: row(`<p class="om-text" style="margin:0;font-family:${ctx.font};font-size:16px;line-height:1.6;color:${ctx.c.text};text-align:${a}">${html}</p>`, 'padding:0 0 16px 0'),
      text,
    };
  },

  list(block, ctx, where) {
    if (!Array.isArray(block.items) || block.items.length === 0) throw new OneMailError(`${where}.items must be a non-empty array`);
    const ordered = Boolean(block.ordered);
    const items = block.items.map((item, i) => inline(item, ctx, `${where}.items[${i}]`));
    const tag = ordered ? 'ol' : 'ul';
    return {
      html: row(`<${tag} class="om-text" style="margin:0;padding:0 0 0 24px;font-family:${ctx.font};font-size:16px;line-height:1.6;color:${ctx.c.text}">${items.map((item) => `<li style="margin:0 0 6px 0">${item.html}</li>`).join('')}</${tag}>`, 'padding:0 0 12px 0'),
      text: items.map((item, i) => `${ordered ? `${i + 1}.` : '-'} ${item.text}`).join('\n'),
    };
  },

  button(block, ctx, where) {
    const label = requireString(block.text, `${where}.text`);
    const href = safeHref(block.href, where);
    const a = align(block.align, where);
    const { primary, buttonText } = ctx.c;
    // Bulletproof: the padded <td> carries the color (Outlook ignores <a> padding),
    // and a same-colored border on the <a> makes the whole area clickable elsewhere.
    const button = `<table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin:0${a === 'center' ? ' auto' : ''}">`
      + `<tr><td align="center" bgcolor="${primary}" class="om-button" style="border-radius:8px;background-color:${primary}">`
      + `<a href="${h(href)}" target="_blank" class="om-button-link" style="display:inline-block;padding:13px 26px;border:1px solid ${primary};border-radius:8px;font-family:${ctx.font};font-size:16px;font-weight:700;line-height:1.2;color:${buttonText};text-decoration:none">${h(label)}</a>`
      + `</td></tr></table>`;
    return { html: `<tr><td align="${a}" style="padding:8px 0 24px 0">${button}</td></tr>`, text: `${label}: ${href}` };
  },

  code(block, ctx, where) {
    const code = requireString(block.code, `${where}.code`);
    const label = block.label === undefined ? '' : requireString(block.label, `${where}.label`);
    const labelHtml = label ? `<p class="om-muted" style="margin:0 0 8px 0;font-family:${ctx.font};font-size:13px;line-height:1.4;color:${ctx.c.muted}">${h(label)}</p>` : '';
    return {
      html: row(`${labelHtml}<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td align="center" class="om-code" style="padding:16px 12px;border:1px solid ${ctx.c.border};border-radius:8px;background-color:${ctx.c.background};font-family:${MONO};font-size:30px;line-height:1.2;font-weight:700;letter-spacing:6px;color:${ctx.c.text}">${h(code)}</td></tr></table>`, 'padding:0 0 20px 0'),
      text: `${label ? `${label}\n\n` : ''}    ${code}`,
    };
  },

  keyValue(block, ctx, where) {
    if (!Array.isArray(block.rows) || block.rows.length === 0) throw new OneMailError(`${where}.rows must be a non-empty array of { label, value }`);
    const rows = block.rows.map((r, i) => {
      if (!isPlainObject(r) || typeof r.label !== 'string' || (typeof r.value !== 'string' && typeof r.value !== 'number')) {
        throw new OneMailError(`${where}.rows[${i}] must be { label: string, value: string | number, bold? }`);
      }
      return r;
    });
    const titleHtml = block.title ? `<p class="om-text" style="margin:0 0 8px 0;font-family:${ctx.font};font-size:15px;font-weight:700;color:${ctx.c.text}">${h(block.title)}</p>` : '';
    const cells = rows.map((r, i) => {
      const weight = r.bold ? '700' : '400';
      const top = i === 0 ? '' : `border-top:1px solid ${ctx.c.border};`;
      const cell = `padding:10px 0;${top}font-family:${ctx.font};font-size:15px;line-height:1.4;font-weight:${weight};`;
      return `<tr><td class="om-text om-rule" style="${cell}color:${ctx.c.text}">${h(r.label)}</td><td align="right" class="om-text om-rule" style="${cell}text-align:right;color:${ctx.c.text}">${h(r.value)}</td></tr>`;
    }).join('');
    const width = Math.max(...rows.map((r) => r.label.length));
    const text = rows.map((r) => `${r.label.padEnd(width)}  ${r.value}`).join('\n');
    return {
      html: row(`${titleHtml}<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="width:100%">${cells}</table>`, 'padding:0 0 20px 0'),
      text: block.title ? `${block.title}\n${text}` : text,
    };
  },

  divider(block, ctx) {
    return {
      html: row(`<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td class="om-rule" style="height:1px;line-height:1px;font-size:0;border-top:1px solid ${ctx.c.border}">&nbsp;</td></tr></table>`, 'padding:8px 0 24px 0'),
      text: '----',
    };
  },

  image(block, ctx, where) {
    if (!parseUrl(block.src, ['https:'])) throw new OneMailError(`${where}.src must be an absolute https:// URL`);
    if (typeof block.alt !== 'string') throw new OneMailError(`${where}.alt is required (use "" only for decorative images)`);
    if (!Number.isInteger(block.width) || block.width < 1 || block.width > CONTENT) throw new OneMailError(`${where}.width must be an integer from 1 to ${CONTENT}`);
    if (block.height !== undefined && (!Number.isInteger(block.height) || block.height < 1)) throw new OneMailError(`${where}.height must be a positive integer`);
    const a = align(block.align ?? 'center', where);
    const heightAttr = block.height ? ` height="${block.height}"` : '';
    let img = `<img src="${h(block.src)}" alt="${h(block.alt)}" width="${block.width}"${heightAttr} style="display:block;width:100%;max-width:${block.width}px;height:auto;border:0;outline:none;text-decoration:none;${a === 'center' ? 'margin:0 auto;' : ''}">`;
    let text = block.alt ? `[${block.alt}]` : '';
    if (block.href !== undefined) {
      const href = safeHref(block.href, where);
      img = `<a href="${h(href)}" target="_blank" style="text-decoration:none">${img}</a>`;
      text = linkText(block.alt || href, href);
    }
    const caption = block.caption ? `<p class="om-muted" style="margin:8px 0 0 0;font-family:${ctx.font};font-size:13px;line-height:1.4;color:${ctx.c.muted};text-align:${a}">${h(block.caption)}</p>` : '';
    if (block.caption) text = [text, block.caption].filter(Boolean).join('\n');
    return { html: row(`${img}${caption}`, `padding:0 0 20px 0;text-align:${a}`), text };
  },

  small(block, ctx, where) {
    const { html, text } = inline(block.text, ctx, where, { color: ctx.c.muted });
    const a = align(block.align, where);
    return {
      html: row(`<p class="om-muted" style="margin:0;font-family:${ctx.font};font-size:13px;line-height:1.5;color:${ctx.c.muted};text-align:${a}">${html}</p>`, 'padding:0 0 12px 0'),
      text,
    };
  },

  /** Unescaped escape hatch for migrations. You own the safety of `html`. */
  raw(block, ctx, where) {
    if (typeof block.html !== 'string') throw new OneMailError(`${where}.html must be a string`);
    if (typeof block.text !== 'string') throw new OneMailError(`${where}.text (the plain-text version) must be a string`);
    return { html: row(block.html, 'padding:0 0 16px 0'), text: block.text };
  },
};
BLOCKS.table = BLOCKS.keyValue;
BLOCKS.footnote = BLOCKS.small;

// ---- Layout -----------------------------------------------------------------

function renderFooter(ctx, { kind, unsubscribeUrl, reason }) {
  const { brand, c } = ctx;
  const f = brand.footer;
  const link = (href, label) => `<a href="${h(href)}" class="om-muted" style="color:${c.muted};text-decoration:underline">${h(label)}</a>`;
  const htmlLines = [];
  const textLines = [];

  if (reason !== undefined) {
    if (typeof reason !== 'string') throw new OneMailError('reason must be a string');
    htmlLines.push(h(reason));
    textLines.push(reason);
  }
  if (f.note) {
    htmlLines.push(h(f.note));
    textLines.push(f.note);
  }
  const contact = [];
  const contactText = [];
  if (f.supportEmail) {
    contact.push(link(`mailto:${f.supportEmail}`, f.supportEmail));
    contactText.push(f.supportEmail);
  }
  if (f.website) {
    contact.push(link(f.website, f.website.replace(/^https?:\/\//, '').replace(/\/$/, '')));
    contactText.push(f.website);
  }
  if (contact.length) {
    htmlLines.push(contact.join(' &middot; '));
    textLines.push(contactText.join(' | '));
  }
  htmlLines.push(`${h(f.legalName)}<br>${f.address.map(h).join('<br>')}`);
  textLines.push([f.legalName, ...f.address].join('\n'));

  if (unsubscribeUrl) {
    const label = brand.unsubscribe?.label || 'Unsubscribe';
    htmlLines.push(link(unsubscribeUrl, label));
    textLines.push(`${label}: ${unsubscribeUrl}`);
  }

  const html = htmlLines.map((line) => `<p class="om-muted" style="margin:0 0 10px 0;font-family:${ctx.font};font-size:12px;line-height:1.6;color:${c.muted};text-align:center">${line}</p>`).join('');
  return { html, text: textLines.join('\n\n') };
}

function logo(ctx) {
  const { brand } = ctx;
  if (!brand.logoUrl) {
    return `<span class="om-text" style="font-family:${ctx.font};font-size:20px;font-weight:700;color:${ctx.c.text}">${h(brand.name)}</span>`;
  }
  const height = brand.logoHeight ? ` height="${brand.logoHeight}"` : '';
  const img = (src, cls, extra = '') => `<img src="${h(src)}" alt="${h(brand.name)}" width="${brand.logoWidth}"${height} class="${cls}" style="display:block;width:${brand.logoWidth}px;max-width:100%;height:auto;border:0;outline:none;text-decoration:none;margin:0 auto;${extra}">`;
  if (!brand.logoDarkUrl) return img(brand.logoUrl, 'om-logo');
  // Dark logo is hidden by default and swapped in by the dark-mode CSS (Apple Mail, iOS, some others).
  return img(brand.logoUrl, 'om-logo om-logo-light')
    + `<!--[if !mso]><!--><div class="om-logo-dark-wrap" style="display:none;max-height:0;overflow:hidden;mso-hide:all">${img(brand.logoDarkUrl, 'om-logo om-logo-dark')}</div><!--<![endif]-->`;
}

function darkCss(c) {
  const d = c.dark;
  const rules = [
    `.om-bg{background-color:${d.background} !important}`,
    `.om-card{background-color:${d.surface} !important;border-color:${d.border} !important}`,
    `.om-text{color:${d.text} !important}`,
    `.om-muted{color:${d.muted} !important}`,
    `.om-link{color:${d.link} !important}`,
    `.om-rule{border-color:${d.border} !important}`,
    `.om-code{background-color:${d.background} !important;border-color:${d.border} !important;color:${d.text} !important}`,
    `.om-button{background-color:${d.primary} !important}`,
    `.om-button-link{background-color:${d.primary} !important;border-color:${d.primary} !important;color:${d.buttonText} !important}`,
  ];
  const swap = '.om-logo-light{display:none !important}.om-logo-dark-wrap{display:block !important;max-height:none !important}';
  return `@media (prefers-color-scheme: dark){${rules.join('')}${swap}}`
    // Outlook.com and Outlook apps tag dark mode with these attributes.
    + rules.map((rule) => `[data-ogsc] ${rule}`).join('');
}

function shell(ctx, { subject, preheader, body, footer, lang }) {
  const { c } = ctx;
  return `<!DOCTYPE html>
<html lang="${h(lang)}" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="x-apple-disable-message-reformatting">
<meta name="format-detection" content="telephone=no, date=no, address=no, email=no, url=no">
<meta name="color-scheme" content="light dark">
<meta name="supported-color-schemes" content="light dark">
<title>${h(subject)}</title>
<!--[if mso]><noscript><xml><o:OfficeDocumentSettings><o:PixelsPerInch>96</o:PixelsPerInch></o:OfficeDocumentSettings></xml></noscript><![endif]-->
<style>
:root{color-scheme:light dark;supported-color-schemes:light dark}
body{margin:0;padding:0;width:100% !important;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%}
table{border-collapse:collapse;mso-table-lspace:0pt;mso-table-rspace:0pt}
img{-ms-interpolation-mode:bicubic}
a[x-apple-data-detectors]{color:inherit !important;text-decoration:none !important}
@media only screen and (max-width:620px){.om-pad{padding-left:20px !important;padding-right:20px !important}}
${darkCss(c)}
</style>
</head>
<body class="om-bg" style="margin:0;padding:0;background-color:${c.background}">
<div style="display:none;font-size:1px;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;mso-hide:all">${h(preheader)}${PREHEADER_SPACER}</div>
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" class="om-bg" bgcolor="${c.background}" style="width:100%;background-color:${c.background}">
<tr><td align="center" style="padding:24px 12px">
<!--[if mso]><table role="presentation" width="${WIDTH}" cellpadding="0" cellspacing="0" border="0"><tr><td><![endif]-->
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="width:100%;max-width:${WIDTH}px">
<tr><td align="center" style="padding:8px 16px 20px 16px">${logo(ctx)}</td></tr>
<tr><td class="om-card om-pad" bgcolor="${c.surface}" style="padding:${PAD}px;background-color:${c.surface};border:1px solid ${c.border};border-radius:12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="width:100%">
${body}
</table>
</td></tr>
<tr><td class="om-pad" style="padding:24px ${PAD}px 8px ${PAD}px">${footer}</td></tr>
</table>
<!--[if mso]></td></tr></table><![endif]-->
</td></tr>
</table>
</body>
</html>
`;
}
