// Small shared helpers. No dependencies.

const HTML_ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/**
 * Escape a value for HTML text or a double-quoted attribute.
 * @param {unknown} value
 * @returns {string}
 */
export function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => HTML_ESCAPES[char]);
}

/** Error thrown for invalid input. `problems` lists every issue found. */
export class OneMailError extends Error {
  /**
   * @param {string} message
   * @param {string[]} [problems]
   */
  constructor(message, problems = []) {
    super(problems.length ? `${message}:\n- ${problems.join('\n- ')}` : message);
    this.name = 'OneMailError';
    this.problems = problems;
  }
}

export const isPlainObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
export const isNonEmptyString = (value) => typeof value === 'string' && value.trim() !== '';

const EMAIL_RE = /^[^\s@<>()",;:]+@[^\s@<>()",;:]+\.[^\s@<>()",;:]+$/;
export const isEmail = (value) => typeof value === 'string' && EMAIL_RE.test(value);

export const HEX_RE = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
export const isHexColor = (value) => typeof value === 'string' && HEX_RE.test(value);

/**
 * Parse an absolute URL and check its scheme.
 * @param {unknown} value
 * @param {string[]} schemes allowed protocols, e.g. ['https:']
 * @returns {URL | null}
 */
export function parseUrl(value, schemes) {
  if (typeof value !== 'string' || /[\s<>"]/.test(value)) return null;
  try {
    const url = new URL(value);
    return schemes.includes(url.protocol) ? url : null;
  } catch {
    return null;
  }
}

/** Schemes allowed in links inside an email body. */
export const LINK_SCHEMES = ['https:', 'http:', 'mailto:', 'tel:'];

/**
 * Require a safe link URL, or throw.
 * @param {unknown} href
 * @param {string} where
 * @returns {string}
 */
export function safeHref(href, where) {
  if (!parseUrl(href, LINK_SCHEMES)) {
    throw new OneMailError(`${where}: href must be an absolute http(s), mailto: or tel: URL (got ${JSON.stringify(href)})`);
  }
  return /** @type {string} */ (href);
}

/** Reject CR/LF so a value can never smuggle extra mail headers. */
export function assertSingleLine(value, where) {
  if (typeof value !== 'string' || /[\r\n]/.test(value)) {
    throw new OneMailError(`${where} must be a single-line string`);
  }
  return value;
}
