import { OneMailError, isPlainObject, isNonEmptyString, isEmail, isHexColor, parseUrl } from './util.js';

/** Light-mode defaults for every color except `primary`, which each brand must set. */
export const DEFAULT_COLORS = Object.freeze({
  text: '#1f2328',
  muted: '#5f6b7a',
  background: '#f4f5f7',
  surface: '#ffffff',
  border: '#e3e6ea',
  buttonText: '#ffffff',
});

/** Dark-mode defaults, used by clients that honour prefers-color-scheme. */
export const DEFAULT_DARK_COLORS = Object.freeze({
  text: '#e8eaed',
  muted: '#a3acb9',
  background: '#121417',
  surface: '#1c1f24',
  border: '#2e333a',
});

const COLOR_KEYS = ['primary', 'link', ...Object.keys(DEFAULT_COLORS)];
const DARK_KEYS = ['primary', 'link', 'buttonText', ...Object.keys(DEFAULT_DARK_COLORS)];
const MAX_LOGO_WIDTH = 300;

/**
 * Validate a brand config and return a normalized, frozen copy with defaults
 * filled in. Throws a OneMailError listing every problem at once.
 *
 * @param {import('./index.js').BrandInput} input
 * @returns {import('./index.js').Brand}
 */
export function defineBrand(input) {
  if (input && input[NORMALIZED]) return input;
  const problems = [];
  const fail = (path, message) => problems.push(`brand.${path} ${message}`);

  if (!isPlainObject(input)) throw new OneMailError('Invalid brand config', ['brand must be an object']);

  if (!isNonEmptyString(input.name)) fail('name', 'is required (the product name shown in the header and footer)');

  if (input.logoUrl !== undefined && !parseUrl(input.logoUrl, ['https:'])) fail('logoUrl', 'must be an absolute https:// URL to a transparent PNG');
  if (input.logoDarkUrl !== undefined && !parseUrl(input.logoDarkUrl, ['https:'])) fail('logoDarkUrl', 'must be an absolute https:// URL');
  if (input.logoDarkUrl !== undefined && input.logoUrl === undefined) fail('logoDarkUrl', 'needs logoUrl as well');
  if (input.logoUrl !== undefined) {
    if (!Number.isInteger(input.logoWidth) || input.logoWidth < 16 || input.logoWidth > MAX_LOGO_WIDTH) {
      fail('logoWidth', `must be an integer from 16 to ${MAX_LOGO_WIDTH} (display width in px; serve the image at 2x)`);
    }
    if (input.logoHeight !== undefined && (!Number.isInteger(input.logoHeight) || input.logoHeight < 1)) fail('logoHeight', 'must be a positive integer');
  }

  const colors = input.colors;
  if (!isPlainObject(colors)) {
    fail('colors', 'is required, with at least colors.primary (hex like #2463eb)');
  } else {
    if (colors.primary === undefined) fail('colors.primary', 'is required (hex like #2463eb)');
    for (const [key, value] of Object.entries(colors)) {
      if (key === 'dark') continue;
      if (!COLOR_KEYS.includes(key)) fail(`colors.${key}`, `is not a known color (use ${COLOR_KEYS.join(', ')}, dark)`);
      else if (!isHexColor(value)) fail(`colors.${key}`, `must be a hex color like #2463eb (got ${JSON.stringify(value)})`);
    }
    if (colors.dark !== undefined) {
      if (!isPlainObject(colors.dark)) fail('colors.dark', 'must be an object');
      else for (const [key, value] of Object.entries(colors.dark)) {
        if (!DARK_KEYS.includes(key)) fail(`colors.dark.${key}`, `is not a known dark color (use ${DARK_KEYS.join(', ')})`);
        else if (!isHexColor(value)) fail(`colors.dark.${key}`, `must be a hex color like #2463eb (got ${JSON.stringify(value)})`);
      }
    }
  }

  const from = input.from;
  if (!isPlainObject(from)) fail('from', 'is required: { name, email }');
  else {
    if (!isNonEmptyString(from.name) || /[\r\n"<>]/.test(from.name)) fail('from.name', 'is required and must not contain quotes, angle brackets or line breaks');
    if (!isEmail(from.email)) fail('from.email', `must be an email address (got ${JSON.stringify(from.email)})`);
  }
  if (input.replyTo !== undefined && !isEmail(input.replyTo)) fail('replyTo', `must be an email address (got ${JSON.stringify(input.replyTo)})`);

  const footer = input.footer;
  if (!isPlainObject(footer)) fail('footer', 'is required: { legalName, address: [lines] } (a physical mailing address is required for commercial email)');
  else {
    if (!isNonEmptyString(footer.legalName)) fail('footer.legalName', 'is required (e.g. "Acme Example LLC")');
    if (!Array.isArray(footer.address) || footer.address.length === 0 || !footer.address.every(isNonEmptyString)) {
      fail('footer.address', 'must be a non-empty array of address lines');
    }
    if (footer.supportEmail !== undefined && !isEmail(footer.supportEmail)) fail('footer.supportEmail', 'must be an email address');
    if (footer.website !== undefined && !parseUrl(footer.website, ['https:', 'http:'])) fail('footer.website', 'must be an absolute http(s) URL');
    if (footer.note !== undefined && typeof footer.note !== 'string') fail('footer.note', 'must be a string');
  }

  const unsubscribe = input.unsubscribe;
  if (unsubscribe !== undefined) {
    if (!isPlainObject(unsubscribe)) fail('unsubscribe', 'must be an object: { url?, mailto?, label? }');
    else {
      if (unsubscribe.url !== undefined && !parseUrl(unsubscribe.url, ['https:'])) fail('unsubscribe.url', 'must be an absolute https:// URL');
      if (unsubscribe.mailto !== undefined && !isEmail(String(unsubscribe.mailto).replace(/^mailto:/i, '').split('?')[0])) fail('unsubscribe.mailto', 'must be an email address or mailto: URL');
      if (unsubscribe.label !== undefined && !isNonEmptyString(unsubscribe.label)) fail('unsubscribe.label', 'must be a non-empty string');
    }
  }

  if (input.fontFamily !== undefined && (!isNonEmptyString(input.fontFamily) || /[<>;{}]/.test(input.fontFamily))) {
    fail('fontFamily', 'must be a CSS font stack without <, >, ; or braces');
  }

  if (problems.length) throw new OneMailError('Invalid brand config', problems);

  const dark = { ...DEFAULT_DARK_COLORS, ...(colors.dark || {}) };
  const light = { ...DEFAULT_COLORS, ...colors };
  delete light.dark;
  light.link ??= light.primary;
  dark.primary ??= light.primary;
  dark.link ??= dark.primary;
  dark.buttonText ??= light.buttonText;

  const brand = {
    name: input.name.trim(),
    logoUrl: input.logoUrl,
    logoDarkUrl: input.logoDarkUrl,
    logoWidth: input.logoUrl ? input.logoWidth : undefined,
    logoHeight: input.logoHeight,
    fontFamily: input.fontFamily || "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
    colors: { ...light, dark },
    from: { name: from.name.trim(), email: from.email },
    replyTo: input.replyTo,
    footer: {
      legalName: footer.legalName.trim(),
      address: footer.address.map((line) => line.trim()),
      supportEmail: footer.supportEmail,
      website: footer.website,
      note: footer.note,
    },
    unsubscribe: unsubscribe ? { ...unsubscribe } : undefined,
  };
  Object.defineProperty(brand, NORMALIZED, { value: true });
  return deepFreeze(brand);
}

/** Alias of defineBrand, for call sites that read better as a check. */
export const validateBrand = defineBrand;

/**
 * The From header value: `"Name" <email>`.
 * @param {import('./index.js').BrandInput} brandInput
 */
export function formatFrom(brandInput) {
  const brand = defineBrand(brandInput);
  return `"${brand.from.name}" <${brand.from.email}>`;
}

const NORMALIZED = Symbol('onemail.brand');

function deepFreeze(value) {
  for (const child of Object.values(value)) if (child && typeof child === 'object') deepFreeze(child);
  return Object.freeze(value);
}
