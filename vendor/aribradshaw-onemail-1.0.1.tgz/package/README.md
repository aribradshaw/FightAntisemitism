# OneMail

Branded, compliant email for plain Node apps. One `render()` call turns a brand config and a list of blocks into email-client-safe HTML and a matching plain-text version. One `headers()` call adds one-click unsubscribe headers to anything that isn't transactional.

- Zero runtime dependencies. Plain ESM JavaScript with TypeScript types, Node 20+.
- Table-based layout, inline styles, 600px wide. Built for Gmail, Outlook (desktop and web), Apple Mail and iOS Mail.
- Dark-mode safe: `color-scheme` meta, `prefers-color-scheme` and Outlook `[data-ogsc]` overrides, an optional dark logo, and no white-boxed images.
- A hidden preheader with spacer padding, so body text doesn't leak into the inbox preview.
- Everything is HTML-escaped by default. Links come only from explicit `{ text, href }` parts with http(s), mailto: or tel: URLs.
- Works with any sender: Resend, nodemailer, SES, Postmark.

Brand data (logo, colors, From address, mailing address) belongs in each app's own repo. This repo holds only the engine and fictional example brands.

## Install

npm isn't used for releases. Install the tarball from a GitHub release, or vendor it:

```sh
npm install https://github.com/aribradshaw/onemail/releases/download/v1.0.1/aribradshaw-onemail-1.0.1.tgz
```

To vendor it, download the `.tgz` into your repo (for example `vendor/`) and run `npm install ./vendor/aribradshaw-onemail-1.0.1.tgz`.

## Quick start

```js
import { render, formatFrom } from '@aribradshaw/onemail';
import brand from './email-brand.mjs';

const email = render({
  brand,
  subject: 'Your sign-in code is 482913',
  preheader: 'It expires in 10 minutes.',
  blocks: [
    { type: 'heading', text: "Confirm it's you" },
    { type: 'paragraph', text: 'Enter this code to finish signing in.' },
    { type: 'code', code: '482913', label: 'Your one-time code' },
    { type: 'small', text: "If you didn't try to sign in, ignore this email." },
  ],
});

// Resend
await resend.emails.send({
  from: formatFrom(brand),
  replyTo: brand.replyTo,
  to,
  subject: email.subject,
  html: email.html,
  text: email.text,
  headers: email.headers,
});
```

`render()` returns `{ subject, html, text, headers }`. With nodemailer, pass the same fields (`from`, `to`, `subject`, `html`, `text`, `headers`).

## Brand config

Keep one of these per product in the app's repo. `defineBrand()` validates it once and returns a frozen, normalized copy; `render()` also accepts the raw object.

```js
// email-brand.mjs
import { defineBrand } from '@aribradshaw/onemail';

export default defineBrand({
  name: 'Acme Example',
  // Transparent PNG with padding built in, served at 2x logoWidth. No white box.
  logoUrl: 'https://acme.example.com/email/logo@2x.png',
  logoDarkUrl: 'https://acme.example.com/email/logo-dark@2x.png', // optional
  logoWidth: 150,
  colors: {
    primary: '#2463eb',            // required: buttons and links
    // optional: text, muted, background, surface, border, link, buttonText
    dark: { primary: '#5b8cff' },  // optional dark-mode overrides
  },
  from: { name: 'Acme Example', email: 'hello@acme.example.com' },
  replyTo: 'support@acme.example.com',
  footer: {
    legalName: 'Acme Example LLC',
    address: ['100 Example Way, Suite 1', 'Anytown, ST 00000'],
    supportEmail: 'support@acme.example.com',
    website: 'https://acme.example.com',
    note: 'Optional line shown in every footer.',
  },
  // Defaults for marketing/bulk mail. Prefer a per-recipient unsubscribeUrl at send time.
  unsubscribe: { url: 'https://acme.example.com/unsubscribe', mailto: 'unsubscribe@acme.example.com', label: 'Unsubscribe' },
});
```

Invalid configs throw a `OneMailError` that lists every problem at once, each with its path (for example `brand.colors.primary must be a hex color like #2463eb (got "blue")`).

## Blocks

| Block | Fields |
| --- | --- |
| `heading` | `text`, `level` (1-3), `align` |
| `paragraph` | `text` (inline), `align` |
| `list` | `items` (inline[]), `ordered` |
| `button` | `text`, `href`, `align` |
| `code` | `code`, `label` (one-time codes) |
| `keyValue` / `table` | `rows: [{ label, value, bold }]`, `title` (receipts) |
| `divider` | |
| `image` | `src` (https), `alt` (required), `width` (max 536), `height`, `href`, `caption`, `align` |
| `small` / `footnote` | `text` (inline), `align` |
| `raw` | `html`, `text` (unescaped escape hatch for migrations) |

Inline text is a string, or an array of strings and `{ text, href?, bold?, italic? }` parts:

```js
{ type: 'paragraph', text: ['Read the ', { text: 'changelog', href: 'https://acme.example.com/changelog' }, '.'] }
```

Strings are never parsed for markup, so user-supplied names can't inject links or tags. In plain text, links render as `text (url)`.

## Unsubscribe headers

```js
import { headers } from '@aribradshaw/onemail';

headers({ kind: 'transactional' });
// {}

headers({ kind: 'marketing', unsubscribeUrl: 'https://acme.example.com/u/abc123', unsubscribeMailto: 'unsubscribe@acme.example.com' });
// {
//   'List-Unsubscribe': '<https://acme.example.com/u/abc123>, <mailto:unsubscribe@acme.example.com>',
//   'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click'
// }
```

- `transactional`: receipts, codes, password resets, account notices. No unsubscribe headers or footer link.
- `marketing` and `bulk`: one-click List-Unsubscribe (RFC 8058), which Gmail and Yahoo require of bulk senders, plus an unsubscribe link in the footer. Throws without an https unsubscribe URL.

Pass `kind`, `unsubscribeUrl` and `unsubscribeMailto` to `render()` and the result's `headers` is already filled in. Your unsubscribe URL must accept a `POST` with body `List-Unsubscribe=One-Click` and unsubscribe without asking anything more. Use `reason` for a footer line such as "You get this because you subscribed to Acme news."

## Preview

```sh
npm run preview
```

Renders every sample email (verification code, password reset, receipt, newsletter) for every example brand to `preview/index.html`, with the plain text and headers beside each one. Switch your OS or browser to dark mode to check dark rendering.

To review real brands without committing them, point the script at a module in your app's repo and write outside this repo's tracked files:

```sh
node scripts/preview.mjs --brands ../my-app/email-brands.mjs --out .scratch/preview
```

## Migrating existing templates

- **`layout(title, body)` with an HTML string body** (for example a hand-rolled shell plus `escape()`): move the title to a `heading` block, split paragraphs into `paragraph` blocks, and turn styled `<a>` buttons into `button` blocks. While you migrate, wrap any piece you haven't converted yet in a `raw` block with its plain-text version. Remove the hard-coded mailing address constant; it now comes from `brand.footer`.
- **`shell({ preheader, body })`**: `preheader` maps directly. The header wordmark becomes `brand.logoUrl` (or just `brand.name`), and the footer lines become `brand.footer` plus a per-message `reason`.
- **`renderTransactionalEmail({ heading, greeting, body, buttonLabel, buttonUrl, secondaryLabel, secondaryUrl, noteTitle, noteBody, detailRows })`**: `heading` → `heading`, `greeting`/`body` → `paragraph`s, `buttonLabel`/`buttonUrl` → `button`, `secondaryLabel`/`secondaryUrl` → a `small` block with a link part, `noteTitle`/`noteBody` → a `heading` level 3 plus `paragraph`, `detailRows` → `keyValue` rows (or a `paragraph` per row when rows carry links).
- **Hand-written plain text**: delete it. `render()` produces `text` from the same blocks, so the two versions can't drift.
- **Newsletter or digest sends**: set `kind: 'marketing'` (or `'bulk'`), pass the per-recipient `unsubscribeUrl`, and send `email.headers` with the message.

## Versioning

OneMail uses [Bradshaw Versioning](https://github.com/aribradshaw/devlog/blob/main/docs/bradshaw-versioning.md), not SemVer: `YEAR.MONTH.UPDATE`, with a one-based project year from 2026 (2026 is year `1`), project-relative months from November 2026 (November is month `0`, resetting to `0` each January) and the America/Phoenix timezone. `1.0.1` is the first release. The numbers are calendar identities, not compatibility promises: pin an exact version and read the release notes before upgrading.

## Development

```sh
npm test                          # node:test, no dependencies
UPDATE_SNAPSHOTS=1 npm test       # rewrite test/snapshots after an intended layout change
npm run preview
npm pack                          # builds the release tarball
```

## License

MIT
